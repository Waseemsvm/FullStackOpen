# The Phone Book

Features

- You can filter the list in the phonebook with the name of the person
- You can add the details of a new person using the form
- You can update the contact of the existing person by name
- You can remove the contact of the person from the list.